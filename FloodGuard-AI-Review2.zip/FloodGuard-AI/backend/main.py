from datetime import datetime, timezone
from pathlib import Path
import sqlite3
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DB_PATH = Path(__file__).with_name("floodguard.db")
app = FastAPI(title="FloodGuard AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500", "http://localhost:5500",
                   "http://127.0.0.1:5173", "http://localhost:5173",
                   "null"],
    allow_credentials=False, allow_methods=["*"], allow_headers=["*"],
)

class ReportIn(BaseModel):
    location: str = Field(min_length=2, max_length=160)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    severity: str = Field(pattern="^(low|moderate|high)$")
    description: str = Field(min_length=3, max_length=1000)

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            location TEXT NOT NULL, latitude REAL, longitude REAL,
            severity TEXT NOT NULL, description TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Reported',
            risk INTEGER NOT NULL, created_at TEXT NOT NULL
        )""")

def risk_score(severity: str) -> int:
    # Initial illustrative rule-based score; not a validated flood forecast.
    return {"low": 22, "moderate": 48, "high": 78}[severity]

@app.on_event("startup")
def startup():
    init_db()

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "FloodGuard AI API"}

@app.get("/api/reports")
def get_reports():
    with connect() as con:
        rows = con.execute("SELECT * FROM reports ORDER BY id DESC").fetchall()
    return [dict(row) for row in rows]

@app.post("/api/reports", status_code=201)
def create_report(report: ReportIn):
    if (report.latitude is None) != (report.longitude is None):
        raise HTTPException(status_code=422, detail="Provide both latitude and longitude, or neither.")
    created_at = datetime.now(timezone.utc).isoformat()
    with connect() as con:
        cur = con.execute(
            """INSERT INTO reports(location,latitude,longitude,severity,description,status,risk,created_at)
               VALUES(?,?,?,?,?,'Reported',?,?)""",
            (report.location, report.latitude, report.longitude, report.severity,
             report.description, risk_score(report.severity), created_at)
        )
        row = con.execute("SELECT * FROM reports WHERE id=?", (cur.lastrowid,)).fetchone()
    return dict(row)

@app.get("/api/risk")
def get_risk():
    with connect() as con:
        rows = con.execute(
            "SELECT location,severity,risk,status,created_at FROM reports ORDER BY id DESC"
        ).fetchall()
    return {
        "method": "illustrative severity-to-score rule",
        "validated_forecast": False,
        "items": [dict(row) for row in rows]
    }

@app.get("/api/dashboard")
def dashboard():
    with connect() as con:
        total = con.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
        high = con.execute("SELECT COUNT(*) FROM reports WHERE severity='high'").fetchone()[0]
        review = con.execute("SELECT COUNT(*) FROM reports WHERE status='Under review'").fetchone()[0]
    return {"total_reports": total, "high_severity": high, "under_review": review,
            "weather_connected": False,
            "note": "Weather integration is not configured in this prototype."}

@app.patch("/api/reports/{report_id}/status")
def update_status(report_id: int, status: str):
    if status not in {"Reported", "Under review", "Resolved"}:
        raise HTTPException(status_code=400, detail="Unsupported status.")
    with connect() as con:
        cur = con.execute("UPDATE reports SET status=? WHERE id=?", (status, report_id))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Report not found.")
        row = con.execute("SELECT * FROM reports WHERE id=?", (report_id,)).fetchone()
    return dict(row)
