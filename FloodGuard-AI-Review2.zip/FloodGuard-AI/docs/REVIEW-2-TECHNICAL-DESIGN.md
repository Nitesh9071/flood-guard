# FloodGuard AI — Review 2: Solution Blueprint & Technical Design

## 1. Problem and proposed solution
FloodGuard AI is a prototype concept for communicating local waterlogging reports and presenting an initial, explainable risk indicator for Bengaluru. It is intended as a decision-support prototype, not an official warning system.

## 2. Current technology stack
- **Frontend:** HTML, CSS, JavaScript
- **Map:** Leaflet with online OpenStreetMap tiles
- **Backend:** Python + FastAPI
- **Database:** SQLite (`backend/floodguard.db`, created on startup)
- **API documentation:** FastAPI Swagger UI at `/docs`

## 3. System architecture
See [`architecture.svg`](architecture.svg). The frontend and backend currently run as separate components. The browser stores submitted demo reports in local storage; the backend API separately stores reports in SQLite. They are **not yet integrated** in this starter version.

## 4. Current data flow
1. A user views the dashboard and map in the browser.
2. The user can submit a sample waterlogging report through the frontend form; this starter frontend stores it in browser local storage.
3. Separately, a client can send a report to `POST /api/reports`.
4. FastAPI validates the fields and saves the API-submitted report to SQLite.
5. `GET /api/reports`, `GET /api/dashboard`, and `GET /api/risk` expose stored report information and summary values.

## 5. Risk scoring and ML status
The backend currently maps reported severity to an illustrative score: low = 22, moderate = 48, high = 78. This is a transparent demo rule, **not a trained machine-learning model and not a validated flood forecast**. No labelled training dataset or trained model is included in this starter project. A future ML model would require suitable historical flood labels and relevant features (for example, rainfall history, location/topography, drainage characteristics, and past inundation records), followed by held-out evaluation.

## 6. Security and validation in this prototype
- Pydantic validates required report fields, string lengths, severity values, and latitude/longitude ranges.
- The API requires both coordinates together or neither.
- SQL values are passed as query parameters rather than concatenated into SQL strings.
- CORS is limited to the local development origins currently listed in `backend/main.py`.
- **Not implemented:** user authentication, role-based access, rate limiting, report moderation, production secrets management, and deployment hardening. Do not expose this development server publicly as-is.

## 7. Scalability and sustainability
SQLite is appropriate for a small local demonstration. For a larger deployment, migrate to PostgreSQL/PostGIS, separate the API from the UI, add caching and monitoring, and ingest reliable official weather and flood datasets. Keep data sources, timestamps, and uncertainty visible to users. Add accessibility checks and low-bandwidth behavior before wider use.

## 8. UI/UX and accessibility goals
The prototype provides a dashboard, interactive map, incident report form, and incident list. Next improvements should include keyboard navigation, clear labels and validation messages, color-plus-text risk indicators, mobile layout checks, and a non-map list alternative for users who cannot use the map.

## 9. Current feasibility / honest status
**Works in the starter:** static dashboard and map; browser-side demo report flow; FastAPI endpoints; SQLite-backed API reports; API docs.

**Not yet complete:** frontend-to-backend integration; live weather connection; validated ML model; authenticated users; verified live incident feed; safe-route calculation.

## 10. Demo checklist for Review 2
- [ ] Open `frontend/index.html` (or serve the frontend locally) and show the dashboard/map.
- [ ] Run FastAPI and open `http://127.0.0.1:8000/docs`.
- [ ] Demonstrate `GET /api/health`, `GET /api/dashboard`, and `GET /api/risk`.
- [ ] Explain the architecture diagram and current separation between frontend local storage and backend SQLite.
- [ ] Clearly describe risk scores as illustrative, not AI predictions.
- [ ] State the next build step: connect frontend report actions to the API and then add verified data sources.
