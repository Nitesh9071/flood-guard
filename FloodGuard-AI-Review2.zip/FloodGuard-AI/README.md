# FloodGuard AI — Hackathon MVP

A beginner-friendly prototype for an urban flooding hackathon. It contains a dashboard, an interactive Bengaluru map, incident reporting, a simple risk score, and a small FastAPI/SQLite backend.

## Review 2 materials
- Technical design, current status, data flow, security, scalability, and demo checklist: `docs/REVIEW-2-TECHNICAL-DESIGN.md`
- Architecture diagram: `docs/architecture.svg` (open in a browser or insert into your presentation).

## Important prototype limitations
- The three initial map incidents are fictional examples, not verified live flood reports.
- The browser frontend currently saves new reports in browser local storage. The backend API independently saves reports to SQLite. These are starter components and are **not yet connected together**.
- Risk scores are illustrative severity-to-score mappings, not validated flood forecasts.
- Live weather data, authentication, verified incident feeds, and safe-route computation are not configured.
- The map uses online OpenStreetMap tiles and requires internet access.

## Run the frontend (simplest)
Open `frontend/index.html` in a browser. For best results, use VS Code's Live Server extension and open the file with Live Server. The interactive map needs an internet connection.

## Run the backend
From the project root, open a terminal:

### Windows PowerShell
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
uvicorn main:app --reload
```

If PowerShell blocks activation, use:
```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn main:app --reload
```

Open `http://127.0.0.1:8000/docs` for interactive API documentation.
Check `http://127.0.0.1:8000/api/health` for the health endpoint.

## Main API endpoints
- `GET /api/health`
- `GET /api/reports`
- `POST /api/reports`
- `GET /api/risk`
- `GET /api/dashboard`
- `PATCH /api/reports/{report_id}/status?status=Under%20review`

## Next implementation step
Connect `frontend/app.js` to the FastAPI endpoints, replace local-storage report persistence with API calls, and test the complete report-to-map workflow before adding weather integration.
