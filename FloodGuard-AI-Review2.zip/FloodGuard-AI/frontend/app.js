const KEY = "floodguard_reports_v1";
const initialReports = [
 {id:1,location:"Example Junction A",latitude:12.9716,longitude:77.5946,severity:"high",description:"Illustrative sample: significant waterlogging reported.",status:"Under review",risk:78,reported:"Sample"},
 {id:2,location:"Example Road B",latitude:12.9352,longitude:77.6245,severity:"moderate",description:"Illustrative sample: water accumulation near roadside.",status:"Reported",risk:48,reported:"Sample"},
 {id:3,location:"Example Area C",latitude:12.9981,longitude:77.5501,severity:"low",description:"Illustrative sample: minor water accumulation.",status:"Reported",risk:22,reported:"Sample"}
];
let reports = loadReports();
function loadReports(){try{const saved=localStorage.getItem(KEY);return saved?JSON.parse(saved):initialReports.map(x=>({...x}));}catch{return initialReports.map(x=>({...x}));}}
function save(){localStorage.setItem(KEY,JSON.stringify(reports));}
function riskFor(severity){return severity==="high"?78:severity==="moderate"?48:22;}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function updateStats(){
 document.getElementById("totalReports").textContent=reports.length;
 document.getElementById("highReports").textContent=reports.filter(r=>r.severity==="high").length;
 document.getElementById("reviewReports").textContent=reports.filter(r=>r.status==="Under review").length;
}
function renderRows(){
 const tbody=document.getElementById("incidentRows");
 tbody.innerHTML=reports.slice().reverse().map(r=>`<tr><td>${escapeHtml(r.location)}</td><td><span class="severity ${r.severity}">${escapeHtml(r.severity)}</span></td><td><b>${r.risk}/100</b></td><td><span class="status">${escapeHtml(r.status)}</span></td><td>${escapeHtml(r.reported)}</td><td><button class="row-action" data-id="${r.id}">${r.status==="Resolved"?"Reopen":"Review"}</button></td></tr>`).join("");
 tbody.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{const r=reports.find(x=>x.id===Number(b.dataset.id));if(!r)return;r.status=r.status==="Resolved"?"Reported":r.status==="Under review"?"Resolved":"Under review";save();refresh();}));
}
let map;
function markerColor(s){return s==="high"?"#dc4c58":s==="moderate"?"#d99020":"#1b9a75";}
function renderMap(){
 if(!map || !window.L)return;
 if(window.markerLayer)window.markerLayer.remove();
 window.markerLayer=L.layerGroup().addTo(map);
 reports.forEach(r=>{
  if(!Number.isFinite(Number(r.latitude))||!Number.isFinite(Number(r.longitude)))return;
  const marker=L.circleMarker([Number(r.latitude),Number(r.longitude)],{radius:9,color:"#fff",weight:2,fillColor:markerColor(r.severity),fillOpacity:.95}).addTo(window.markerLayer);
  marker.bindPopup(`<strong>${escapeHtml(r.location)}</strong><br>Severity: ${escapeHtml(r.severity)}<br>Risk score: ${r.risk}/100<br><small>${escapeHtml(r.description)}</small><br><em>Demo/report data; verify locally.</em>`);
 });
}
function refresh(){updateStats();renderRows();renderMap();}
document.getElementById("reportForm").addEventListener("submit",e=>{
 e.preventDefault();
 const location=document.getElementById("location").value.trim(),description=document.getElementById("description").value.trim();
 const latRaw=document.getElementById("latitude").value,lonRaw=document.getElementById("longitude").value;
 const latitude=latRaw===""?null:Number(latRaw),longitude=lonRaw===""?null:Number(lonRaw);
 if((latitude===null)!==(longitude===null)){document.getElementById("formMessage").textContent="Enter both coordinates, or leave both blank.";return;}
 if(latitude!==null&&(!Number.isFinite(latitude)||latitude < -90||latitude>90||longitude < -180||longitude>180)){document.getElementById("formMessage").textContent="Please enter valid coordinates.";return;}
 const severity=document.getElementById("severity").value;
 reports.push({id:Date.now(),location,latitude,longitude,severity,description,status:"Reported",risk:riskFor(severity),reported:new Date().toLocaleString()});
 save();refresh();e.target.reset();document.getElementById("formMessage").textContent="Report saved in this browser. Thank you.";
});
document.querySelectorAll(".nav").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".nav").forEach(n=>n.classList.remove("active"));btn.classList.add("active");document.getElementById(btn.dataset.view)?.scrollIntoView({behavior:"smooth",block:"start"});}));
if(window.L){
 map=L.map("map").setView([12.9716,77.5946],11);
 L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
 renderMap();
}else{document.getElementById("map").innerHTML="<p style='padding:20px'>Map library unavailable. Check your internet connection.</p>";}
refresh();
